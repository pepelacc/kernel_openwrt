/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _ASM_IA64_RESOURCE_H
#define _ASM_IA64_RESOURCE_H

#include <asm/ustack.h>
#include <asm-generic/resource.h>

#endif /* _ASM_IA64_RESOURCE_H */

/* SPDX-License-Identifier: GPL-2.0 */
// Copyright (C) 2005-2017 Andes Technology Corporation

#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

/* This file is required by include/linux/linkage.h */
#define __ALIGN .align 2
#define __ALIGN_STR ".align 2"

#endif
